import { Metadata } from "next";
import { AuthProvider } from "@/hooks/useAuth";

export const metadata: Metadata = {
  title: "Đặt lại mật khẩu | RAG System",
  description: "Đặt lại mật khẩu cho tài khoản của bạn",
};

export default function ResetPasswordLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-1">
        <AuthProvider>{children}</AuthProvider>
      </main>
    </div>
  );
} 