"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/components/ui/use-toast";
import { z } from "zod";
import { useAuth } from "@/hooks/useAuth";

// Schema for password validation
const passwordSchema = z.string()
  .min(8, "Mật khẩu phải có ít nhất 8 ký tự")
  .regex(/[A-Z]/, "Mật khẩu phải có ít nhất một chữ hoa")
  .regex(/[a-z]/, "Mật khẩu phải có ít nhất một chữ thường")
  .regex(/[0-9]/, "Mật khẩu phải có ít nhất một chữ số");

export default function ResetPasswordPage() {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const { resetPassword } = useAuth();

  useEffect(() => {
    // Extract token from URL hash fragment
    const getAccessTokenFromHash = (): string | null => {
      if (typeof window === 'undefined') return null;
      
      const hash = window.location.hash.substring(1); // Remove # at the beginning
      const params = new URLSearchParams(hash);
      return params.get('access_token');
    };

    const token = getAccessTokenFromHash();
    if (token) {
      setAccessToken(token);
      // Clean the URL by removing the hash fragment after extracting the token
      if (typeof window !== 'undefined') {
        window.history.replaceState({}, document.title, window.location.pathname);
      }
    } else {
      setError("Không tìm thấy token xác thực trong URL. Vui lòng kiểm tra liên kết hoặc yêu cầu liên kết mới.");
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!accessToken) {
      toast({
        variant: "warning",
        title: "Cảnh báo",
        description: "Không tìm thấy token xác thực. Vui lòng yêu cầu liên kết đặt lại mật khẩu mới."
      });
      return;
    }

    // Validate password
    try {
      passwordSchema.parse(password);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        toast({
          variant: "warning",
          title: "Cảnh báo",
          description: error.errors[0].message
        });
      } else {
        toast({
          variant: "warning",
          title: "Cảnh báo",
          description: "Mật khẩu không hợp lệ"
        });
      }
      return;
    }

    // Check if passwords match
    if (password !== confirmPassword) {
      toast({
        variant: "warning",
        title: "Cảnh báo",
        description: "Mật khẩu xác nhận không khớp"
      });
      return;
    }

    try {
      setLoading(true);
      
      // Call resetPassword method from useAuth hook
      await resetPassword(accessToken, password);
      
      // Hiển thị toast thành công
      toast({
        variant: "success",
        title: "Thành công",
        description: "Mật khẩu của bạn đã được đặt lại thành công."
      });
      
      setSuccess(true);
      
      // Redirect to login page after 3 seconds
      setTimeout(() => {
        router.push("/auth/login");
      }, 3000);
    } catch (error: any) {
      // Hiển thị lỗi
      let errorMessage = "Không thể đặt lại mật khẩu";
      
      if (error instanceof Error && error.message) {
        errorMessage = error.message;
        
        // Xử lý trường hợp mật khẩu mới giống mật khẩu cũ
        if (error.message.includes("Mật khẩu mới phải khác mật khẩu cũ")) {
          toast({
            variant: "warning",
            title: "Cảnh báo",
            description: "Mật khẩu mới phải khác mật khẩu cũ của bạn.    mật khẩu khác."
          });
          return;
        }
      }
      
      toast({
        variant: "destructive",
        title: "Lỗi",
        description: errorMessage
      });
    } finally {
      setLoading(false);
    }
  };

  if (error) {
    return (
      <div className="flex justify-center items-center min-h-[calc(100vh-8rem)]">
        <Card className="w-full max-w-md shadow-lg">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center">Đặt lại mật khẩu</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="p-4 bg-red-50 text-red-700 rounded-md">
              <p className="text-center">{error}</p>
            </div>
            <div className="mt-4">
              <Button
                variant="outline"
                className="w-full"
                onClick={() => router.push("/auth/forgot-password")}
              >
                Yêu cầu liên kết mới
              </Button>
            </div>
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-sm text-muted-foreground">
              <Link href="/auth/login" className="text-primary hover:underline">
                Quay lại đăng nhập
              </Link>
            </p>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex justify-center items-center min-h-[calc(100vh-8rem)]">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center">Đặt lại mật khẩu</CardTitle>
          <CardDescription className="text-center">
            Nhập mật khẩu mới cho tài khoản của bạn
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!success ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password">Mật khẩu mới</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  disabled={loading}
                />
                <p className="text-xs text-muted-foreground">
                  Mật khẩu phải có ít nhất 8 ký tự, bao gồm chữ hoa, chữ thường và số.
                  Mật khẩu mới phải khác mật khẩu cũ của bạn.
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Xác nhận mật khẩu</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  disabled={loading}
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Đang xử lý..." : "Đặt lại mật khẩu"}
              </Button>
            </form>
          ) : (
            <div className="space-y-4">
              <div className="p-4 bg-green-50 text-green-700 rounded-md">
                <p className="text-center">
                  Mật khẩu của bạn đã được đặt lại thành công.
                  Bạn sẽ được chuyển hướng đến trang đăng nhập trong vài giây.
                </p>
              </div>
              <Button
                className="w-full"
                onClick={() => router.push("/auth/login")}
              >
                Đăng nhập ngay
              </Button>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          <p className="text-sm text-muted-foreground">
            <Link href="/auth/login" className="text-primary hover:underline">
              Quay lại đăng nhập
            </Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  );
} 